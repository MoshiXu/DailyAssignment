package serialization;


import java.io.Serializable;


public class Employee implements Serializable {
    String name;
    String address;
     transient int ssn;
    int id;
    
     public void mailCheck() {
      System.out.println("Mailing a check to " + name + " " + address);
   }
    
}

