
package fileio;


import java.io.*;
public class CopyFile {

   public static void main(String args[]) throws IOException {  
      
       
       FileInputStream in = null;
       
      FileOutputStream out = null;

      try {
         in = new FileInputStream("input.txt");
         out = new FileOutputStream("output.txt");
         
         int c;
         while ((c = in.read()) != -1) {
            out.write(c);
         }
      }catch(IOException e){
          System.out.println("in catch");
      }
      finally {
         if (in != null) {
            in.close();
         }
         if (out != null) {
            out.close();
         }
      }
   }
}
